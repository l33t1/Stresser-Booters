<?php
$name = "Ticket";
include 'header.php';

if (!$user-> Question($odb))
{
   header('Location: index');
}
$id = ($_GET['id']);
if(is_numeric($id) == false) {
header('Location: index');
exit;
}

$SQLCheckID = $odb -> prepare("SELECT COUNT(*) FROM `tickets` WHERE `id` = :id AND `username` = :user LIMIT 1");
$SQLCheckID -> execute(array(':id' => $id, ':user' => $_SESSION['username']));
$countID= $SQLCheckID -> fetchColumn(0);
if ($countID == 0)
{
header('Location: tableau-de-bord'); 
}

if (isset($_POST['fermer']))
{
$SQLupdate = $odb -> prepare("UPDATE `tickets` SET `status` = :status, `etat` = 1 WHERE `id` = :id");
$SQLupdate -> execute(array(':status' => '<span class="label label-danger">Résolu</span>', ':id' => $id));
header('refresh: 0;');
}
$SQLGetTickets = $odb -> prepare("SELECT * FROM `tickets` WHERE `id` = $id");
$SQLGetTickets -> execute(array(':username' => $_SESSION['username']));
$getInf = $SQLGetTickets -> fetch();
$username = $getInf['username'];
$subject = $getInf['subject'];
$status = $getInf['status'];
$etat = $getInf['etat'];
$original = $getInf['content'];
$date = $getInf['date'];
$categorie = $getInfo['categorie'];
$date = strftime("%d %B - %H:%M", $getInf['date']);
?>



         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-8 mt-3">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">Messages</h4>
                              <div class="col-xl-12">
                                 <div id="dragula-left" class="py-2">
                                    <div class="card rounded border mb-2">
                                       <div class="card-body p-3">
                                          <div class="media">
                                             <div class="media-body">
                                                <h6 class="mb-1"><i class="icon-user"></i> DarlingSh <small class=" ml-1 mb-0">// Updated 4 minutes ago</small></h6>
                                                <p class="mt-3 text-muted">
                                                   do you sell api 
                                                </p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-xl-12">
                                 <div id="dragula-left" class="py-2">
                                    <div class="card rounded border mb-2">
                                       <div class="card-body p-3">
                                          <div class="media">
                                             <div class="media-body">
                                                <h6 class="mb-1"><i class="icon-user"></i> Admin <small class=" ml-1 mb-0">// Posted 4 minutes ago</small></h6>
                                                <p class="mt-3 text-muted">
                                                   Hello,<br />
                                                   Of course.<br />
                                                   Our Premium / Enterprise plans include API.<br /><br />
                                                   Regards.
                                                </p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="form-group mt-3">
                                 <form method="POST" action="https://webstress.net/request/ticket/reply/182">
                                    <input type="hidden" id="__csrf" name="__csrf" value="71064a1146e5af0bd399a3dba4f88af3n99re2rnhd9cvlg0jio1lkk7ql743refCS176181184193refCSf29ad2a52f268d3977ea5426c28327a1"/>
                                    <div class="form-group"><label for="content">Message</label><textarea class="form-control" name="content" placeholder="" id="content" rows="7"></textarea></div>
                                    <div class="text-center"><button type="submit" class="btn btn-info mt-3 mt-2"><i class="icon-cursor"></i> Send</button></div>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-4 mt-3">
                        <div class="card mb-3">
                           <div class="card-body">
                              <h4 class="card-title">Ticket N°182</h4>
                              <table class="table">
                                 <tbody>
                                    <tr>
                                       <th scope="row">Status</th>
                                       <td class="text-white" style="width: 50%"><span class='badge badge-primary'>Answered</span></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Last Update</th>
                                       <td class="text-white" style="width: 50%">18 Jan. 2021, 04:19 PM</td>
                                    </tr>
                                 </tbody>
                              </table>
                              <div class="row">
                                 <form class="col-xl-12" method="POST" action="https://webstress.net/request/ticket/manage/182">
                                    <input type="hidden" id="__csrf" name="__csrf" value="71064a1146e5af0bd399a3dba4f88af3n99re2rnhd9cvlg0jio1lkk7ql743refCS176181184193refCSf29ad2a52f268d3977ea5426c28327a1"/>
                                    <div class="form-group"><button type="submit" name="close" value="1" class="btn btn-danger btn-sm btn-block mt-3"><i class="icon-close"></i> Close</button></div>
                                 </form>
                              </div>
                              <div class="row">
                                 <div class="col-md-12"><a href="https://webstress.net/support" class="btn btn-dark btn-sm btn-block mt-1"><i class="icon-arrow-left-circle"></i> Go back</a></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <footer class="footer">
                  <div class="w-100 clearfix text-center"><span class="text-muted d-block text-center d-sm-inline-block">Copyright © 2020-2021 WebStress. All rights reserved.</span></div>
               </footer>
               <script src="https://cdnjs.cloudflare.com/ajax/libs/js-sha256/0.9.0/sha256.min.js"></script><script type="text/javascript">var Tawk_API=Tawk_API||{},Tawk_LoadStart=new Date;const rand=()=>Math.random(0).toString(36).substr(2),token=a=>(rand()+rand()+rand()+rand()).substr(0,a);var mail=token(40)+"@webstress.net",username="DarlingSh";Tawk_API.visitor={name:""==username?"visitor-"+Math.floor(99999*Math.random())+1:username,email:mail,hash:sha256.hmac("ffe32650cc423fc7d5a84fb364e7186f72353901",mail)},function(){var a=document.createElement("script"),e=document.getElementsByTagName("script")[0];a.async=!0,a.src="https://embed.tawk.to/5fd9079aa8a254155ab3aa8e/1epjsbcvf",a.charset="UTF-8",a.setAttribute("crossorigin","*"),e.parentNode.insertBefore(a,e)}();</script><script type="text/javascript">_atrk_opts = { atrk_acct:"QR/Ov1khOY20xx", domain:"webstress.net",dynamic: true};(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://certify-js.alexametrics.com/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();</script>
               <noscript><img alt="Alexa rank" src="https://certify.alexametrics.com/atrk.gif?account=QR/Ov1khOY20xx" style="display:none" height="1" width="1" alt="" /></noscript>
            </div>
         </div>
      </div>
      <script src="https://webstress.net/app/base.js"></script><script src="https://webstress.net/app/template.js"></script><script src="https://webstress.net/app/todolist.js"></script><script src="https://webstress.net/app/toastr.min.js"></script><script src="https://webstress.net/app/tooltips.js"></script><script src="https://webstress.net/lib/frontend/js/getnotif.js"></script>
   </body>
</html>