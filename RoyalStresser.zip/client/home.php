<?php 
session_start();
$page = "Home";
include 'header.php';

       $lastactive = $odb -> prepare("UPDATE `users` SET activity=UNIX_TIMESTAMP() WHERE username=:username");
       $lastactive -> execute(array(':username' => $_SESSION['username']));

    $onedayago = time() - 86400;

    $twodaysago = time() - 172800;
    $twodaysago_after = $twodaysago + 86400;

    $threedaysago = time() - 259200;
    $threedaysago_after = $threedaysago + 86400;

    $fourdaysago = time() - 345600;
    $fourdaysago_after = $fourdaysago + 86400;

    $fivedaysago = time() - 432000;
    $fivedaysago_after = $fivedaysago + 86400;

    $sixdaysago = time() - 518400;
    $sixdaysago_after = $sixdaysago + 86400;

    $sevendaysago = time() - 604800;
    $sevendaysago_after = $sevendaysago + 86400;
    
    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` > :date");
    $SQL -> execute(array(":date" => $onedayago));
    $count_one = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $twodaysago, ":after" => $twodaysago_after));
    $count_two = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $threedaysago, ":after" => $threedaysago_after));
    $count_three = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $fourdaysago, ":after" => $fourdaysago_after));
    $count_four = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $fivedaysago, ":after" => $fivedaysago_after));
    $count_five = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $sixdaysago, ":after" => $sixdaysago_after));
    $count_six = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $sevendaysago, ":after" => $sevendaysago_after));
    $count_seven = $SQL->fetchColumn(0);

    
    $date_one = date('d/m/Y', $onedayago);
    $date_two = date('d/m/Y', $twodaysago);
    $date_three = date('d/m/Y', $threedaysago);
    $date_four = date('d/m/Y', $fourdaysago);
    $date_five = date('d/m/Y', $fivedaysago);
    $date_six = date('d/m/Y', $sixdaysago);
    $date_seven = date('d/m/Y', $sevendaysago);


      $plansql = $odb -> prepare("SELECT `users`.`expire`, `plans`.`name`, `plans`.`concurrents`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id");
      $plansql -> execute(array(":id" => $_SESSION['ID']));
      $row = $plansql -> fetch(); 
      $date = date("m-d-Y, h:i:s a", $row['expire']);
      if (!$user->hasMembership($odb)){
        $row['mbt'] = 0;
        $row['concurrents'] = 0;
        $row['name'] = 'n/a';
        $row['membership'] = 'n/a';
        $date = 'n/a';
        $SQLupdate = $odb -> prepare("UPDATE `users` SET `expire` = 0 WHERE `username` = ?");
        $SQLupdate -> execute(array($_SESSION['username']));
      }
      
      $SQL = $odb -> prepare("SELECT * FROM `users` WHERE `username` = :usuario");
                    $SQL -> execute(array(":usuario" => $_SESSION['username']));
                    $balancebyripx = $SQL -> fetch();
                    $balance = $balancebyripx['balance'];
          
          
          if ($user -> isAdmin($odb)){ 
        
        $rank =' <span class="badge badge-primary shadow-primary m-1"> Administrateur</span>';
         
        }
        
        else if ($user -> isVip($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Advance User</span>';
        }
        else if ($user -> hasMembership($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Paid</span>';
        }
        else if ($user -> isSupport($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Staff</span>';
        }
        else { 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Free </span>';
        }
      
      if (isset($_GET['wel']))
    {
        
        {
          
          echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: "true",
  type: "info",
  title: "Welcome back '. $_SESSION['username'] .' WebStress.gg !",
  showConfirmButton: false,
  timer: 4500
  
});';
  echo ' }, 1000);</script>';
  
        }
        
      }
      
      
      
    ?>

<div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-12">
                        <div class="card card-statistics">
                           <div class="card-body p-0">
                              <div class="row">
                                 <div class="col-md-6 col-lg-3">
                                    <div class="d-flex justify-content-between border-right card-statistics-item">
                                       <div>
                                          <h2><?php echo $TotalUsers; ?></h2>
                                          <p class="text-muted mb-0">Registered users</p>
                                       </div>
                                       <i class="icon-people text-primary icon-lg"></i>
                                    </div>
                                 </div>
                                 <div class="col-md-6 col-lg-3">
                                    <div class="d-flex justify-content-between border-right card-statistics-item">
                                       <div>
                                          <h2><?php echo $RunningAttacks; ?></h2>
                                          <p class="text-muted mb-0">Running attacks</p>
                                       </div>
                                       <i class="icon-energy text-primary icon-lg"></i>
                                    </div>
                                 </div>
                                 <div class="col-md-6 col-lg-3">
                                    <div class="d-flex justify-content-between border-right card-statistics-item">
                                       <div>
                                          <h2>0</h2>
                                          <p class="text-muted mb-0">Online Users</p>
                                       </div>
                                       <i class="icon-login text-primary icon-lg"></i>
                                    </div>
                                 </div>
                                 <div class="col-md-6 col-lg-3">
                                    <div class="d-flex justify-content-between card-statistics-item">
                                       <div>
                                          <h2><?php echo $TotalPools; ?></h2>
                                          <p class="text-muted mb-0">Online servers</p>
                                       </div>
                                       <i class="icon-layers text-primary icon-lg"></i>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title mb-3">Hello, <?php echo $_SESSION['username']; ?></h4>
                              <p class="mb-0">Need help ? Create a new ticket on our <a href="support">support page.</a></p>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-xl-8 mt-3 stretch-card">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">Latest Update</h4>
                              <h3>

                                <?php 
              $SQLGetNews = $odb -> query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 1");
              while ($getInfo = $SQLGetNews -> fetch(PDO::FETCH_ASSOC)){
                $id = $getInfo['ID'];
                $title = $getInfo['title'];
                   $color = $getInfo['color'];

                  $icon = $getInfo['icon'];
                $content = $getInfo['content'];
                $date9 = _ago($getInfo['date']);
                echo ' <h3">
                '.htmlspecialchars($title).'
                                    <p class="mt-2"><i class="icon-clock"></i> '.$date9.'</p>
                                 </h3>
                              </h3>
                              <p class="font-weight-bold">'.$content.'<br>
                              </p>
                              ';
              }
              ?>

                              <a class="font-weight-bold" href="update/13"><i class="icon-arrow-right-circle"></i> Read More</a>
                           </div>
                        </div>
                     </div>


                     <div class="col-xl-4 mt-3 stretch-card">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">More News</h4>
                              <a href="update" style="text-decoration: none">
                                 <?php 
              $SQLGetNews = $odb -> query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 2");
              while ($getInfo = $SQLGetNews -> fetch(PDO::FETCH_ASSOC)){
                $id = $getInfo['ID'];
                $title = $getInfo['title'];
                   $color = $getInfo['color'];

                  $icon = $getInfo['icon'];
                $content = $getInfo['content'];
                $date9 = _ago($getInfo['date']);
                echo '<a href="update" style="text-decoration: none">
                                 <div class="card rounded border mb-2">
                                    <div class="card-body p-3">
                                       <div class="media">
                                          <i class="icon-grid icon-sm align-self-center mr-3"></i>
                                          <div class="media-body">
                                             <h6 class="mb-1">'.htmlspecialchars($title).'</h6>
                                             <p class="mb-0 text-muted">
                                                Created '.$date9.' ago
                                             </p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </a>';
              }
              ?>
                              <div class="text-center mt-3"><a class="font-weight-bold" href="update"><i class="icon-arrow-right-circle"></i> View All</a></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-xl-8 mt-3">
                        <div class="card-body" style="background: #101010;">
<h4 class="card-title mb-3">Latest Ticket Replied [ Offline ]</h4>
<div class="text-center">
  <h6>
    <i class="icon-layers"></i> No data available.</h6>
  </div>
</div>
                        <div class="card mt-3">
                           <div class="card-body">
                              <h4 class="card-title mb-3">Waiting Invoice [ Offline ]</h4>
                              <div class="text-center">
                                 <h6><i class="icon-layers"></i> No data available.</h6>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-4 mt-3 mb-10">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">Account overview</h4>
                              <table class="table">
                                 <tbody>
                                    <tr>
                                       <th scope="row">Username</th>
                                       <td class="text-white" style="width: 50%"><?php echo $_SESSION['username']; ?></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Balance</th>
                                       <td class="text-white" style="width: 50%"><?php echo number_format((float)$balance); ?> $</td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Plans</th>
                                       <td class="text-white" style="width: 50%"><?php echo $row['name']; ?></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Expire</th>
                                       <td class="text-white" style="width: 50%"><?php echo $date; ?></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Attack Time</th>
                                       <td class="text-white" style="width: 50%"><?php echo $row['mbt']?></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Slots</th>
                                       <td class="text-white" style="width: 50%"><?php echo $row['concurrents']?></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Premium</th>
                                       <td class="text-white" style="width: 50%"><span class="badge badge-danger">n/a</span></td>
                                    </tr>
                                    <tr>
                                       <th scope="row">API</th>
                                       <td class="text-white" style="width: 50%"><span class="badge badge-danger">n/a</span></td>
                                    </tr>
                                 </tbody>

                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
<?php include 'footer.php'; ?>
   </body>
</html>