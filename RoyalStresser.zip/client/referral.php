<?php
$name = "Refferal";
include 'header.php';
?>


         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title mb-3">Start Advertising</h4>
                              <p class="mb-3">Start advertising for WebStress now using your referral url. You will receive a bonus on each sale made by your referred users according to the plan.</p>
                              <div class="form-group"><label for="">
                                 Referral link
                                 </label><input type="text" class="form-control" id="" name="" maxlength="" value="https://your-website-url.gg/register?ref=<?php echo $_SESSION['username']; ?>" placeholder="" onclick="this.select();document.execCommand(&#39;copy&#39;);alert(&#39;Copied&#39;);">
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-xl-8 mt-3">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">Referred Users</h4>
 <?php
$username = $_SESSION['username'];
$IMPORTANT = $odb -> query("SELECT COUNT(*) FROM `referral` WHERE `referredBy` = '$username'");
$anylogs = $IMPORTANT->fetchColumn(0);
if ($anylogs < 1) {

?>
                              <div class="text-center">
                                 <h6><i class="icon-layers"></i> No data available.</h6>
                              </div>
 <?php
}else{
?>
<div class="table-responsive">
                 <table class="table table-striped table-bordereless text-nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th class="">User</th>
                              <th class="">Status</th>
                              <th class="">Amount Earned</th>
                       <th class="">Date</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php 
            
            $SQLGetTickets = $odb -> prepare("SELECT * FROM `referral` WHERE `referredBY` = :name");
            $SQLGetTickets -> execute(array(':name' => $_SESSION['username']));
            while ($getInfo = $SQLGetTickets -> fetch(PDO::FETCH_ASSOC))
            {
            
            
                $referrer = $getInfo['username'];
                $status = $getInfo['status'];
            $amount = $getInfo['amount'];
            $dateeee = date('d \of M Y', $getInfo['date']);
            if($status == '0'){
            $stat = 'No membership found';   
            }else if($status == '1'){
            $stat = '<span class="text-success">Regular</span>';   //here set the accoun rank defined in your source(vip,basic,premium, etc) 
            }else{
            $stat = '<span class="text-warning">VIP</span>';   //here set the accoun rank defined in your source(vip,basic,premium, etc)  
            }


                echo '<tr>
            <td><span class="">'.$referrer.'</span></td>
            <td><span class="">'.$stat.'</span></td>
            <td><span class="text-success">$'.$amount.'</span></td>
            <td><span class="">'.$dateeee.'</span></td>
            </tr>';
            }
            ?>
                        </tbody>
                     </table>
                </div> 
                 <?php
                         
}
?>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-4 mt-3">
                        <div class="card">
                           <div class="card-body">
                             
                              <h4 class="card-title mt-3">Commissions per plan</h4>
                              <table class="table">
                                 <tbody>
                                    <tr>
                                       <th scope="row">Basic</th>
                                       <td class="text-white">5%</td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Premium</th>
                                       <td class="text-white">10%</td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Enterprise</th>
                                       <td class="text-white">20%</td>
                                    </tr>
                                    <tr>
                                       <th scope="row">Free-Stresser</th>
                                       <td class="text-white">0%</td>
                                    </tr>
                                 </tbody>
                              </table>
                              
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php include 'footer.php'; ?>
   </body>
</html>