-------------delete this message-------------
* By submitting a new issue I acknowledge that I already read the README, CODE EXAMPLES and KNOWN LIMITATIONS. 
* I understand that the current version `2.x` is only meant to detect `mobile` devices.
* Please post your User-Agent string! On a real device/s, the library is expected to work correctly.
-------------delete this message-------------



**Issue description**


**User-Agent(s)**


**Suggestions**