<?php 
session_start();
$page = "Settings";
include 'header.php';

$username = $_SESSION['username'];

if(isset($_POST['delete'])){
   
  $SQLKILLER = $odb -> query("DELETE FROM `logins_failed` WHERE `username` = '$username'");
  $SQLKILLER2 = $odb -> query("DELETE FROM `login_history` WHERE `username` = '$username'");
  $SQLKILLER3 = $odb -> query("DELETE FROM `logs` WHERE `user` = '$username'");
   $SQLKILLER4 = $odb -> query("DELETE FROM `loginlogss` WHERE `username` = '$username'");
$SQLCHECKER = $odb -> query("SELECT COUNT(*) FROM `loginlogss` WHERE `username` = '$username'");
$logsafter = $SQLCHECKER->fetchColumn(0);
if ($logsafter < 1) {
    	echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  type: "success",
  title: "Success",
  text: "Done, all logs cleared!",
  showConfirmButton: false,
  timer: 4500
  
});';
  echo ' }, 1000);</script>';
	
}
		

	
	}

if(!empty($_POST['update'])){
		
		if(empty($_POST['old']) || empty($_POST['new'])){
				$error = error('You need to enter both passwords.');
				
							echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: "true",
  type: "error",
  title: "You need to enter both passwords",
  showConfirmButton: false,
  timer: 4500
  
});';
  echo ' }, 1000);</script>';
		}

		$SQLCheckCurrent = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `ID` = :ID AND `password` = :password");
		$SQLCheckCurrent -> execute(array(':ID' => $_SESSION['ID'], ':password' => SHA1(md5($_POST['old']))));
		$countCurrent = $SQLCheckCurrent -> fetchColumn(0);
	
		if ($countCurrent == 0){
			$error = error('Current password is incorrect.');
			echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: "true",
  type: "error",
  title: "Current password is incorrect.",
  showConfirmButton: false,
  timer: 4500
  
});';
  echo ' }, 1000);</script>';
		}
		
		$notify = error($error);
	
		if(empty($error)){
			$SQLUpdate = $odb -> prepare("UPDATE `users` SET `password` = :password WHERE `username` = :username AND `ID` = :id");
			$SQLUpdate -> execute(array(':password' => SHA1(md5($_POST['new'])),':username' => $_SESSION['username'], ':id' => $_SESSION['ID']));
			$error = success('Password has been successfully changed');
			echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: "true",
  type: "success",
  title: "Password Updated",
  showConfirmButton: false,
  timer: 4500
  
});';
  echo ' }, 1000);</script>';
		}
	
	}
	?>

  <?php
    //fetching stats qloq 
      $plansql = $odb -> prepare("SELECT `users`.`expire`, `plans`.`name`, `plans`.`concurrents`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id");
      $plansql -> execute(array(":id" => $_SESSION['ID']));
      $row = $plansql -> fetch(); 
      $date = date("m-d-Y, h:i:s a", $row['expire']);
      if (!$user->hasMembership($odb)){
        $row['mbt'] = 0;
        $row['concurrents'] = 0;
        $row['name'] = 'No membership';
        $date = '0-0-0';
        $SQLupdate = $odb -> prepare("UPDATE `users` SET `expire` = 0 WHERE `username` = ?");
        $SQLupdate -> execute(array($_SESSION['username']));
        
        }
        if ($user -> isAdmin($odb)){ 
        
        $rank =' <span class="badge badge-primary shadow-primary m-1"> Owner</span>';
         
        }
        
        else if ($user -> isVip($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Advance User</span>';
        }
        else if ($user -> hasMembership($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Paid User</span>';
        }
        else if ($user -> isSupport($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Staff</span>';
        }
        else { 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Visitor</span>';
        }
        
        
      ?>


<div class="container-fluid page-body-wrapper">
<div class="main-panel">
<div class="content-wrapper">
<div class="row">
<div class="col-lg-6 mt-4">
<div class="card">
<div class="card-body">

<div class="form-group">
<label for="username" class="col-form-label">Username</label>
<input class="form-control" type="text" disabled="" id="username" value="<?php echo $_SESSION['username']; ?>">
</div>
<div class="form-group">
<label for="plan_time" class="col-form-label">Attack Time</label>
<input class="form-control" type="text" disabled="" id="plan_time" value="<?php echo $row['mbt']; ?>">
</div>
<div class="form-group">
<label for="plan_concs" class="col-form-label">Concurrents</label>
<input class="form-control" type="text" disabled="" id="plan_concs" value="<?php echo $row['concurrents']; ?>">
</div>
<div class="form-group">
<label for="plan_name" class="col-form-label">Subscription</label>
<input class="form-control" type="text" disabled="" id="plan_name" value="<?php echo $row['name']; ?>">
</div>
<div class="form-group">
<label for="expdate" class="col-form-label">Expiration</label>
<input class="form-control" type="text" disabled="" id="expdate" value="<?php echo $date; ?>">
</div>
</div>
</div>
</div>
<div class="col-lg-6 mt-4">
<div class="card">
<div class="card-body">
<h4 class="header-title">Change Password</h4>
<br>
<form id="form">
<div class="form-group">
<label for="oldpassword">Old Password</label>
<input class="form-control" type="password" id="old" name="old" placeholder="Enter your old password..">
</div>
<div class="form-group">
<label for="newpassword1">New Password</label>
<input class="form-control" type="password" id="new" name="new" placeholder="Enter your new password..">
</div>
<button class="btn btn-primary mt-4 pr-4 pl-4" name="update" value="change" type="submit">Update Password</button>
</form>
</div>
</div>
</div>
</div>


<div class="col-lg-12 mt-4">
<div class="card">
<div class="card-body">
Referred Users: <span id="referred">0</span> <i class="fa fa-user"></i><br>
Referral Link: https://webstress.gg/client/register?ref=<?php echo $_SESSION['username']; ?> <br><br>
You will be paid 5-10% of every referral that purchases a subscription. Contact administrator for withdrawal in BTC.
</div>
</div>

<div class="col-lg-12 mt-4">
           <div class="card">
            <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-primary top-icon nav-justified">
            <div class="tab-content p-">
                <div class="tab-pane active" id="profile">
                    <h5 class="mb-3">Account Activity</h5>
                    
         <div class="table-responsive">
           <table class="table table-striped table-borderless table-vcenter">
              <thead>
                <tr>
                  
                  <th style="font-size: 12px;">Name</th>
                  <th style="font-size: 12px;">IP</th>
                  <th style="font-size: 12px;">Country</th>
                  <th style="font-size: 12px;">date</th>
                  <th style="font-size: 12px;">result</th>
                  
                </tr>
              </thead>
              <tbody style="font-size: 12px;">
              <?php
              $SQLGetUsers = $odb -> query("SELECT * FROM `loginlogss` WHERE `username`='{$_SESSION['username']}' ORDER BY `date` DESC LIMIT 5");
              while ($getInfo = $SQLGetUsers -> fetch(PDO::FETCH_ASSOC)){
                $username = $getInfo['username'];
                $ip = $getInfo['ip'];
                $date = date("m-d-Y, h:i:s a", $getInfo['date']);
                $country = $getInfo['country'];
                $result = $getInfo['results'];
                echo '<tr>
                    <td>'.htmlspecialchars($username).'</td>
                    <td> '. $ip .'</td>
                    <td>'. $country .'</td>
                    
                    <td>'. $date .'</td>
                    <td>'. $result .'</td>
                    
                    </tr>';
              }
              ?>  
              </tbody>
            </table>
            </div>
                    <!--/row-->
                </div>