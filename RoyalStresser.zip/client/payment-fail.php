<?php
include_once "Securiity/config.php";
include_once "Securiity/project-security.php";
include('header.php');

?>
<link href="assets/toastr/toastr.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css">
<script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="assets/toastr/toastr.min.js"></script>

<div class="page-wrapper">
								
	 <main id="main-container" style="min-height: 536px;">
  <div class="content">
 <div class="row">
<?php
//echo '<pre>';
//print_r($_POST);
//echo $_POST['payment_status'];
 
	 
	 echo ' <div class="alert alert-danger alert-dismissible animated flipInX">Opss Looks like the transaction was failed</div><br>';
     echo '<meta http-equiv="Refresh" content="5; url=index.php">';

?>
	 
	 </div>
	  </div>
		 </main>
	<?php include('footer.php'); ?>