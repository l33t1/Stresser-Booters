<?php
	$page = "Api Manager";
	include 'header.php'; 
?>


<?php
	if(isset($_POST['gen_key'])){
		if(isset($_SESSION['username'])){
			genKey($_SESSION['username'], $odb);
			header('Location: apimanager.php');
		}
	}
	if(isset($_POST['disable_key'])){
		if(isset($_SESSION['username'])){
			disableKey($_SESSION['username'], $odb);
			header('Location: apimanager.php');
		}
	}

	function genKey($username, $odb){
		$newkey = generateRandomString(16);
		$stmt2 = $odb->query("UPDATE users SET apikey='$newkey' WHERE username='$username'");
	}
	function disableKey($username, $odb){
		$stmt2 = $odb->query("UPDATE users SET apikey='0' WHERE username='$username'");
	}
	function generateRandomString($length = 10){
		$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
		$charactersLength = strlen($characters);
		$randomString = '';
		for($i=0;$i<$length;$i++){
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	$stmt = $odb->prepare("SELECT apikey FROM users WHERE username=:login");
	$stmt->bindParam("login", $_SESSION['username'], PDO::PARAM_STR);
	$stmt->execute();
	$key = $stmt->fetchColumn(0);
?>
         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
<center style="font-weight:bold">
What is our API system?
<br>
<br>
<p> A system that allows you to launch attacks in a more automated way, without having to log-in or open the website, just sending a request or pasting the API in your browser.</p>
<p> The Api can be used for the Layer 7 and Layer 4 Network.</p>
<br>
</center>
<div class="col-lg-12">
<div class="card">
<div class="card-header text-uppercase">Your API (Layer 7)</div>
<form method="POST">
		  		<?php if($key == '0'){?>
	            <input class="form-control" type="text" value="API is unavailable or api-key is disabled! Click 'Generate new api-key'." readonly="" style="color:#cec6c6;">
	            <?php }else{?>
				<?php if($user->api($odb)){?>
				<?php if($user->isVip($odb)){?>
	            <input class="form-control" type="text" value="https://webstress.gg/client/api/api.php?key=<?php echo $key;?>&host=[host]&port=[port]&time=[time]&method=[Method/stop]&vip=[1=on/0=off]" readonly="" style="color:#cec6c6;">
	            <?php }else{?>
				<input class="form-control" type="text" value="https://webstress.gg/client/api/api.php?key=<?php echo $key;?>&host=[ip]&port=[port]&time=[time]&method=[Method/stop]&vip=0" readonly="" style="color:#cec6c6;">
				<?php }?>
				<?php }else{?>
				<input class="form-control" type="text" value="You need plans with api access for use it !" readonly="" style="color:#cec6c6;">
				<?php }?>
				<?php }?>
	            <br><button type="submit" class="btn btn-primary" name="gen_key">Generate new api-key</button> <button type="submit" class="btn btn-danger" name="disable_key">Disable api-key</button>
	        </form>
</div>
</div>

<center style="font-weight:bold">
	<div class="card-header text-uppercase">How to use the api for (Layer 7)</div>
<br>
<ul>
Replace PASSWORD field with your account's password
<br>
<br>
Mode is attack mode. REQUEST = HTTP, PROXY = SOCKET, TOR = TOR
<br>
<br>
Origin is origin attack. ALL = all origins, US = USA, CH = China, EU = EEurope
<br>
<br>
URL is your attack target
<br>
<br>
Time is the attack time
<ul>
</ul></ul></center>
<br>
<center style="font-weight:bold">
	<div class="card-header text-uppercase">How to use the api for (Layer 4)</div>
<br>
<ul>
Replace PASSWORD field with your account's password
<br>
<br>
Target is your attack target(IP)
<br>
<br>
Port is the port(ex : 80)
<br>
<br>
Time is the attack time
<br>
<br>
Method can be : NTP, CLDAP, DNS, XSYN, XACK, NTP-PREMIUM, MIXAMP, ARD, CHARGEN, UDP-MIX
<br>
<br>
To stop the attack set method=STOP
<br>
<br>
<ul>
</ul></ul></center>
</div>
               <?php include 'footer.php'; ?>
   </body>
</html>