<?php
include('header.php');

if($_POST['txn_id'] != '') {
    file_put_contents('log.txt', $_POST['txn_id'].'\n', FILE_APPEND);
    $insert = $odb->prepare("INSERT INTO `AddFunds` VALUES (NULL,?,?,?,?)");
    $insert->execute(array($_SESSION['ID'],$_POST['txn_id'],$_POST['mc_gross'],time()));
}

?>