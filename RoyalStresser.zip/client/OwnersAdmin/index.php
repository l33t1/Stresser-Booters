<?php
{     
    header('Location: home.php'); exit;
    
}
    
{
		 header('Location: private.php');
		 exit;
	     }
?>