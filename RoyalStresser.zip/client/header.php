<?php
require_once 'includes/configuration.php';
require_once 'includes/init.php';

if (!$user -> LoggedIn()){
    header('Location: login');
    exit;
}

function hasBNAccess($db){
   $stmt = $db->prepare("SELECT botnet FROM users WHERE username=:login");
   $stmt->bindParam("login", $_SESSION['username'], PDO::PARAM_STR);
   $stmt->execute();
   $value = $stmt->fetchColumn(0);
   return $value;
}
$lastactive = $odb -> prepare("UPDATE `users` SET activity=UNIX_TIMESTAMP() WHERE username=:username");
$lastactive -> execute(array(':username' => $_SESSION['username']));

 $onedayago = time() - 86400;

 $twodaysago = time() - 172800;
 $twodaysago_after = $twodaysago + 86400;

 $threedaysago = time() - 259200;
 $threedaysago_after = $threedaysago + 86400;

 $fourdaysago = time() - 345600;
 $fourdaysago_after = $fourdaysago + 86400;

 $fivedaysago = time() - 432000;
 $fivedaysago_after = $fivedaysago + 86400;

 $sixdaysago = time() - 518400;
 $sixdaysago_after = $sixdaysago + 86400;

 $sevendaysago = time() - 604800;
 $sevendaysago_after = $sevendaysago + 86400;
 
 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` > :date");
 $SQL -> execute(array(":date" => $onedayago));
 $count_one = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $twodaysago, ":after" => $twodaysago_after));
 $count_two = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $threedaysago, ":after" => $threedaysago_after));
 $count_three = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $fourdaysago, ":after" => $fourdaysago_after));
 $count_four = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $fivedaysago, ":after" => $fivedaysago_after));
 $count_five = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $sixdaysago, ":after" => $sixdaysago_after));
 $count_six = $SQL->fetchColumn(0);

 $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
 $SQL -> execute(array(":before" => $sevendaysago, ":after" => $sevendaysago_after));
 $count_seven = $SQL->fetchColumn(0);
 
 $date_one = date('d/m/Y', $onedayago);
 $date_two = date('d/m/Y', $twodaysago);
 $date_three = date('d/m/Y', $threedaysago);
 $date_four = date('d/m/Y', $fourdaysago);
 $date_five = date('d/m/Y', $fivedaysago);
 $date_six = date('d/m/Y', $sixdaysago);
 $date_seven = date('d/m/Y', $sevendaysago);

     $plansql = $odb -> prepare("SELECT `users`.`expire`, `plans`.`name`, `plans`.`concurrents`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id");
     $plansql -> execute(array(":id" => $_SESSION['ID']));
     $row = $plansql -> fetch(); 
     $date = date("m-d-Y, h:i:s a", $row['expire']);
     if (!$user->hasMembership($odb)){
         $row['mbt'] = 0;
         $row['concurrents'] = 0;
         $row['name'] = 'No membership';
         $date = '0-0-0';
     }
     
     $SQL = $odb -> prepare("SELECT * FROM `users` WHERE `username` = :usuario");
             $SQL -> execute(array(":usuario" => $_SESSION['username']));
             $balancebyripx = $SQL -> fetch();
             $balance = $balancebyripx['balance'];
     
 
?>

<head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
      <title><?php echo $sitename; ?> | <?php echo $page; ?></title>
      <link rel="shortcut icon" href="logo.png" />
      <link rel="apple-touch-icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-120.png" sizes="120x120">
      <link rel="apple-touch-icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-152.png" sizes="152x152">
      <link rel="apple-touch-icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-180.png" sizes="180x180">
      <link rel="shortcut icon" href="logo.png">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-32.png" sizes="32x32">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-57.png" sizes="57x57">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-76.png" sizes="76x76">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-96.png" sizes="96x96">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-128.png" sizes="128x128">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-192.png" sizes="192x192">
      <link rel="icon" href="https://webstress.gg/app/landing/assets/img/icons/favicon-228.png" sizes="228x228">
      <meta content="Welcome to Login of Webstress the best IP Stresser / booter in 2020, Login today and start boot for free." name="description">
      <meta name="keywords" content="free ip stresser,free ip booter,booter,ip stresser,stresser,booter">
      <meta name="msapplication-TileColor" content="#FFFFFF">
      <meta name="msapplication-TileImage" content="https://webstress.gg/app/landing/assets/img/icons/favicon-144.png">
      <meta name="msapplication-config" content="https://webstress.gg/app/landing/assets/img/icons/browserconfig.xml">
      <link rel="canonical" href="https://webstress.gg//client/login">
      <meta name="audience" content="all">
      <meta name="author" content="Webstress.gg">
      <meta property="og:type" content="website">
      <meta property="og:locale" content="en_US">
      <meta property="og:description" content="Webstress is the best IP Stresser / Booter ! We provide free and paid services.">
      <meta property="og:site_name" content="Webstress.gg">
      <meta property="og:url" content="https://webstress.gg/login">
      <meta property="og:image" content="https://webstress.gg/logo.png">
      <meta property="og:title" content="Webstress is the best IP Stresser / Booter">
      <script async="" src="assets/app.js" charset="UTF-8" crossorigin="*"></script>
      <script type="text/javascript" async="" src="assets/atrk.js"></script>
      <script async="" src="assets/1epjsbcvf" charset="UTF-8" crossorigin="*"></script>
      <script type="application/ld+json">{"@context": "https://schema.org","@type": "Organization","name": "Webstress","url": "https://Webstress.gg","logo": "logo.png"}</script>
      <meta name="twitter:card" content="summary">
      <meta name="twitter:site" content="Webstress.gg">
      <meta name="twitter:title" content="WebStress - The best IP Stresser / Booter">
      <meta name="twitter:domain" content="Webstress.gg">
      <meta name="twitter:creator" content="">
      <meta name="twitter:description" content="Webstress is the best IP Stresser / booter in 2020, We also provide free and paid ip stresser / booter services">
      <meta name="twitter:image" content="https://webstress.gg/app/landing/assets/img/logo.png">
      <link rel="stylesheet" href="assets/template.min.css">
      <link rel="stylesheet" href="assets/icon.css">
      <link rel="stylesheet" href="assets/qrcode.min.js">
      <link href="assets/toastr.min.css" rel="stylesheet">
      <link href="assets/fontawesome.css" rel="stylesheet">
      <link rel="stylesheet" href="https://fonticons-free-fonticons.netdna-ssl.com/kits/349cfdf6/publications/110327/woff2.css" media="all">
      <script async="" src="assets/js"></script><script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         gtag('config', 'UA-184475903-1');
      </script>
      <style type="text/css">@keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-moz-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-webkit-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}#vvgc2Oe-1610469367210{outline:none!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:none!important;opacity:1!important;filter:alpha(opacity=100)!important;-ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity1)!important;-moz-opacity:1!important;-khtml-opacity:1!important;top:auto!important;right:10px!important;bottom:0px!important;left:auto!important;position:fixed!important;border:0!important;min-height:0!important;min-width:0!important;max-height:none!important;max-width:none!important;padding:0!important;margin:0!important;-moz-transition-property:none!important;-webkit-transition-property:none!important;-o-transition-property:none!important;transition-property:none!important;transform:none!important;-webkit-transform:none!important;-ms-transform:none!important;width:auto!important;height:auto!important;display:none!important;z-index:2000000000!important;background-color:transparent!important;cursor:auto!important;float:none!important;border-radius:unset!important;pointer-events:auto!important}#vpKbdtm-1610469367211.open{animation : tawkMaxOpen .25s ease!important;}</style>
   </head>
   <body>
      <div class="container-scroller">
         <nav class="navbar horizontal-layout col-lg-12 col-12 p-0">
            <div class="nav-top flex-grow-1">
               <div class="container d-flex flex-row h-100">
                  <div class="text-center navbar-brand-wrapper d-flex align-items-center"><img src="assets/logo.png"></div>
                  <div class="navbar-nav-right navbar-menu-wrapper"><button class="navbar-toggler align-self-right" type="button" data-toggle="minimize"><span class="icon-menu text-light"></span></button></div>
               </div>
            </div>
            <div class="nav-bottom">
               <div class="container">
                  <ul class="nav page-navigation">
                     <li class="nav-item"><a class="nav-link" href="home">
                        <i class="link-icon icon-screen-desktop"></i>
                        <span class="menu-title"> Dashboard</span></a></li>
                     <li class="nav-item "><a class="nav-link" href="hub">
                        <i class="link-icon icon-rocket"></i>
                        <span class="menu-title"> Attack Hub</span></a></li>
                     <li class="nav-item "><a class="nav-link" href="apimanager">
                        <i class="link-icon icon-link"></i>
                        <span class="menu-title"> API Manager</span></a></li>
                     <li class="nav-item "><a class="nav-link" href="upgrade">
                        <i class="link-icon icon-basket"></i>
                        <span class="menu-title"> Upgrade</span></a></li>
                     <li class="nav-item "><a class="nav-link" href="support">
                        <i class="link-icon icon-support"></i>
                        <span class="menu-title"> Support</span></a></li>
                     <li class="nav-item "><a class="nav-link" href="referral">
                        <i class="link-icon icon-tag"></i>
                        <span class="menu-title"> Referral</span></a></li>
                     <li class="nav-item "><a class="nav-link" href="settings"
                        ><i class="link-icon icon-settings"></i>
                        <span class="menu-title"> Settings</span></a></li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout" onclick="document.getElementById(&#39;logout-form&#39;).submit();"><i class="link-icon icon-power"></i><span class="menu-title"> Logout</span></a>
                     </li>
                     <li class="nav-item "><a class="nav-link" href="OwnersAdmin"
                        ><i class="link-icon icon-settings"></i>
                        <span class="menu-title"> Administrateur</span></a></li>
                  </ul>
               </div>
            </div>
         </nav>




         <script src="assets/plugins/jquery-knob/excanvas.js"></script>
<script src="assets/plugins/jquery-knob/jquery.knob.js"></script>



<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js"></script>

  <script>
          window.setInterval(function(){
          var xmlhttp;
          if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest();
          }
          else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
          }
          xmlhttp.onreadystatechange = function(){
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
              var respone = xmlhttp.responseText
              if (xmlhttp.responseText == "SESSION_STATUS_OFF") {
                swal({
                title: "Session ended :(",
                text: "Your Session is over, Disconnects in 3 seconds.",
                timer: 3000,
                showConfirmButton: false
              });
              
              setTimeout(function() {
                document.location = "login";
              }, 3000)
              } else if(xmlhttp.responseText == "KICKED_DONE") {
                swal({
                  title: "Kicked from vStress.io!",
                  text: "The stuff decided to disconnect you from the system!",
                  showCancelButton: false,
                  showConfirmButton: false,
                  allowOutsideClick: false,
                  });
              setTimeout(function() {
                window.location = "login";
              }, 1500)
              } else if(respone.indexOf("PRIVATEMESSAGE_") >= 0) {
                var message = respone.split("_");
                $("#getPrivateMessage").text(message[1]);
                document.getElementById("privateMessage").style.display = "block";
              } else if(respone.indexOf("RECEIVEMONEY_") >= 0) {
                var data = respone.split("_");
                $("#getMoneyMessage").text(data[2]);
                $("#moneybal").text("$" + data[1]);
                document.getElementById("receiveMoney").style.display = "block";
              }
              else if(respone.indexOf("transferMoney") >= 0) {
                document.getElementById("transferMoneyPopup").innerHTML = xmlhttp.responseText;
              }
            
            }
          }         
          xmlhttp.open("GET","functions/checkSESSION.php",true);
          xmlhttp.send();
          
        }, 25000);
        </script>
  
  <button type="button" id="popGift" class="btn btn-alt-warning" data-toggle="modal" data-target="#modal-popGift"></button>
<style>
  #popGift {
    color: transparent;
    background: transparent;
    border: none;
    box-shadow: 0px 0px 0px rgba(0,0,0,0);
        width: 0px;
        height: 0px;
    opacity: 0;
    display:none;

  }
</style>
<script>
  SendPop = setTimeout(function(){
    document.getElementById('popGift').click();
    clearTimeout(SendPop);
  }, 5000);
</script>
<?php
$SQL = $odb -> prepare("SELECT COUNT(*) FROM `users` WHERE `username` = :username AND `dailygiftdate` < UNIX_TIMESTAMP(NOW())");
$SQL -> execute(array(':username' => $_SESSION['username']));
$count = $SQL -> fetchColumn(0);
  if ($count == '1') {  
  $expiresdate = strtotime("+1 day", time());
  $SQLUpdate = $odb -> prepare("UPDATE `users` SET `dailygiftdate`= :dailydate WHERE `username` = :username");
  $SQLUpdate -> execute(array(':username' => $_SESSION['username'], ':dailydate' => $expiresdate));
  $SQL = $odb -> query("UPDATE `users` SET `TestsDaily` = '0' WHERE `id` = '" . $_SESSION['ID'] . "'");
  
$randGift = rand(1, 300);
$getDailyGiftData = $odb -> prepare("SELECT *,COUNT(*) FROM `dailygift` WHERE `number` = :number");
$getDailyGiftData -> execute(array(':number' => $randGift));
$userGift = $getDailyGiftData -> fetch(PDO::FETCH_ASSOC);
if ($userGift['COUNT(*)'] == '0') {
//Nothing = background: linear-gradient(135deg,#ab4444 0,#ab5f57 100%)!important;
//Success = box-shadow: 0 -5px 25px -5px #69ab57, 0 1px 5px 0 rgb(45, 53, 61), 0 0 0 0 #44ab8e;
$ShadowGift = '<div class="modal-content animated bounceIn">';
$TitleGift = 'Oops, You don\'t receive anything';
$HeaderGift = '<div class="card-header">';
$MessageGift = '<center><div class="text-danger">Sorry, But you did not received anything today!</br>Come back tomorrow to check your luck</div><hr><div class="text-warning">Daily Gifts</div></br><bb class="text-danger">Low:</bb> 1$, 2$, 3$</br><bb class="text-warning">Medium:</bb> 4$, 5$</br><bb class="text-success">High:</bb> 10$</center></br>';
} else {
  $ShadowGift = '<div class="modal-content animated bounceIn" style="
    box-shadow: 0 -5px 25px -5px #69ab57, 0 1px 5px 0 rgb(45, 53, 61), 0 0 0 0 #44ab8e;
">';
$HeaderGift = '<div class="card-header ">';
$TitleGift = 'You received a Daily gift :)';
$gift = str_replace('$', '', $userGift['gift']);
$MessageGift = '<center><div class="text-success">Congratulations, you\'ve been awarded a free gift!</div><div class="text-success tossing"><i class="fa fa-gift"></i> You received $' . $gift . ' gift to your acount Balance! <i class="fa fa-gift"></i></div><hr><div class="text-warning">Daily Gifts</div></br><bb class="text-danger">Low:</bb> 1$, 2$, 3$</br><bb class="text-warning">Medium:</bb> 4$, 5$</br><bb class="text-success">High:</bb> 10$</center></br>';

$SQL = $odb -> prepare("SELECT `balance`,`plan` FROM `users` WHERE `username` = :username");
$SQL -> execute(array(':username' => $_SESSION['username']));
$balance = $SQL -> fetch(PDO::FETCH_ASSOC);
$balance['balance'] = $balance['balance'] + $gift;

$SQLUpdate = $odb -> prepare("UPDATE `users` SET `abalance`= :accb WHERE `username` = :username");
$SQLUpdate -> execute(array(':username' => $_SESSION['username'], ':accb' => $balance['balance']));

if($user->isVIP($odb)) {
$usernameSQL = '[<bb class="text-warning">VIP</bb>] ' . $_SESSION['username'] . " - Won: $" . $gift . ".00";
} elseif ($user->hasMembership($odb)) {
$usernameSQL = '[<bb class="text-success">Member</bb>] ' . $_SESSION['username'] . " - Won: $" . $gift . ".00";
} else {
$usernameSQL = '[<bb class="text-gray">User</bb>] ' . $_SESSION['username']. " - Won: $" . $gift . ".00";
}

$SQLUpdate = $odb -> prepare("INSERT INTO `dailygiftwon`(`ID`, `username`, `date`) VALUES (NULL,:username,:date)");
$SQLUpdate -> execute(array(':username' => $usernameSQL, ':date' => $expiresdate));
}
?>
<div class="modal animated flip" id="modal-popGift" tabindex="-1" role="dialog" aria-labelledby="modal-popGift" style="display: none;" aria-hidden="true">
<div class="modal-dialog modal-dialog-popout" role="document">
<?= $ShadowGift; ?>
<div class="card mb-0">
<?= $HeaderGift; ?>
<h3 class="card-title"><i class="fa fa-gift"></i> <?= $TitleGift; ?></h3>
</div>
<div class="card-body">
<?= $MessageGift; ?>
</div>
</div>

</div>
</div>
</div>

  <?php } ?>
         <script>
  function makeread() {
            window.setInterval(function(){
          var xmlhttp;
          if (window.XMLHttpRequest){
            xmlhttp = new XMLHttpRequest();
          }
          else{
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
          }
          xmlhttp.open("GET","functions/read.php?username=<?php echo $_SESSION['username']; ?>",true);
          xmlhttp.send(); 
          }, 500);
          }
</script>
  <script>
            window.setInterval(function(){
          var xmlhttp;
          if (window.XMLHttpRequest){
            xmlhttp = new XMLHttpRequest();
          }
          else{
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
          }
          xmlhttp.open("GET","functions/Complexcheck.php?username=<?php echo $_SESSION['username']; ?>",true);
          xmlhttp.send(); 
          }, 8000);
</script>

<script>
                function logOut() {
            Swal.fire({
                title: 'Are you sure?',
                text: "Are you sure you want to logout?",
                type: 'info',
        
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, logout!'
            }).then((result) => {
                if (result.value) {
                    setTimeout(function () {
                        window.location.replace('logout.php');
                    }, 500);
                    Swal.fire({
                         title: 'Success',
             type: 'success',
                        text: "Redirecting, Bye"
          }
                   )
                }
            })
        }

        
function ShowMyIp() {
const ipAPI = 'https://api.ipify.org?format=json'
swal.queue([{
  title: "Your public IP",
  confirmButtonText: "Show my public IP",
  showLoaderOnConfirm: true,
  preConfirm: () => {
    return fetch(ipAPI)
      .then(response => response.json())
      .then(data => swal.insertQueueStep(data.ip))
      .catch(() => {
        swal.insertQueueStep({
          type: 'error',
          title: 'Unable to get your public IP'
        })
      })
  }
}])

        }
</script>
<script>
xmlhttp.onreadystatechange = function(){
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
              var respone = xmlhttp.responseText
              if (xmlhttp.responseText == "SESSION_STATUS_OFF") {
                swal({
                title: "Session ended :(",
                text: "Your Session is over, Disconnects in 3 seconds.",
                timer: 3000,
                showConfirmButton: false
              });
              
              setTimeout(function() {
                document.location = "login";
              }, 3000)
              } else if(xmlhttp.responseText == "KICKED_DONE") {
                swal({
                  title: "Kicked from vStress.io!",
                  text: "The staff decided to disconnect you from the system!",
                  showCancelButton: false,
                  showConfirmButton: false,
                  allowOutsideClick: false,
                  });
              setTimeout(function() {
                window.location = "login";
              }, 1500)
              } else if(respone.indexOf("PRIVATEMESSAGE_") >= 0) {
                var message = respone.split("_");
                $("#getPrivateMessage").text(message[1]);
                document.getElementById("privateMessage").style.display = "block";
              } else if(respone.indexOf("RECEIVEMONEY_") >= 0) {
                var data = respone.split("_");
                $("#getMoneyMessage").text(data[2]);
                $("#moneybal").text("$" + data[1]);
                document.getElementById("receiveMoney").style.display = "block";
              } else if(respone.indexOf("transferMoney") >= 0) {
                document.getElementById("transferMoneyPopup").innerHTML = xmlhttp.responseText;
              }
            
            }
          }         
          xmlhttp.open("GET","functions/checkSESSION.php",true);
          xmlhttp.send();

</script>