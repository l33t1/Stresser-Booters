<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
<p class="text-muted text-center text-md-left">Copyright 2019/2020 <a href="././index.php" target="_blank">Badbooter.pw</a>. All rights reserved</p>
<p class="text-muted text-center text-md-left mb-0 d-none d-md-block">Made by NullFox <i class="mb-1 text-primary ml-1 icon-small" data-feather="heart"></i></p>
</footer>